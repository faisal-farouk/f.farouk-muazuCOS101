use std::io;

fn main() {
    println!("Enter book code: ");
    let mut input1 = String::new();
    io::stdin().read_line(&mut input1).expect("Not a valid string");
   
}
